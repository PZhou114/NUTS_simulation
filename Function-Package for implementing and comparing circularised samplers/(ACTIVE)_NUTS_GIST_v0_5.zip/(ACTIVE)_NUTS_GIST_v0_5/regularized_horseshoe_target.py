"""Regularized horseshoe Bernoulli-logit posterior for Euclidean HMC/NUTS/GIST.

References: Piironen and Vehtari (2017), Electronic Journal of Statistics.
All coordinates are unconstrained, and all priors include their log-transform
Jacobians. Additive constants independent of q are intentionally omitted.

Coordinates q = [intercept, z(1:p), log_lambda(1:p), t, h], where
  log(tau) = log(tau0) + t, log(c^2) = log(slab_scale^2) + h.

Pass `potential` and `gradient` to the user's make_sampler implementation.
"""
from dataclasses import dataclass
import numpy as np
from scipy.special import expit


@dataclass
class RegularizedHorseshoeLogistic:
    X: np.ndarray  # design matrix X with shape (n,p)
    y: np.ndarray  # binary response vector (0,1)^n
    expected_nonzero: float = 5.0  # p0, anticipated number of relevant predictors/signals
    logistic_scale: float = 2.0  # factor in the calibration of tau0, change this to 1.0 for Claude's recommendation

    # fixed parameter values for c^2 in InvGamma(nu/2, nu s^2/2)
    slab_scale: float = 2.0  # fixed number for scale s
    slab_df: float = 4.0  # fixed number for degree of freedom nu

    # fixed parameter value for beta0 sim N(0, 5^2), as a weakly informative prior
    intercept_sd: float = 5.0
    global_scale: float | None = None  # tau0, calibrated global shrinkage scale

    def __post_init__(self):
        self.X = np.asarray(self.X, dtype=np.float64)
        self.y = np.asarray(self.y, dtype=np.float64)

        if self.X.ndim != 2:
            raise ValueError('X must have shape (n, p)')
        self.n, self.p = self.X.shape

        if self.y.shape != (self.n,) or not np.all(np.isin(self.y, (0, 1))):
            raise ValueError('y must be a binary vector with length n')
        
        if not (self.n > 0 and self.p > 1 and 0 < self.expected_nonzero < self.p):
            raise ValueError('Require n>0, p>1, 0<expected_nonzero<p')
        
        if any(v <= 0 or not np.isfinite(v) for v in
               (self.logistic_scale, self.slab_scale, self.slab_df, self.intercept_sd)):
            raise ValueError('Prior scales and slab degrees-of-freedom must be positive')
        
        if self.global_scale is None:
            self.global_scale = (self.expected_nonzero/(self.p-self.expected_nonzero)
                                 *self.logistic_scale/np.sqrt(self.n))  # follow P-V's derivation in their paper
            
        if not np.isfinite(self.global_scale) or self.global_scale <= 0:
            raise ValueError('global_scale must be positive')
        
        if not np.all(np.isfinite(self.X)):
            raise ValueError('X must be finite')
        
        self.dimension = 2 * self.p + 3  # overall dimension for the augmented position vector

        # Store useful constants, as used repeatedly in posterior calculations
        self._log_tau0 = np.log(self.global_scale)
        self._log_s2 = 2 * np.log(self.slab_scale)
        self._a = self.slab_df / 2

    def _unpack(self, q):
        """
        Recover the individual parameter blocks.
        Divide a vector of length 2p+3 into five related components:
            1. beta0: intercept, shorten as b0 later;
            2. z_1, ... , z_p: Gaussian auxiliaries;
            3. u_1, ... , u_p: log local scales (u_j = log lambda_j);
            4. t: t=log(tau/tau0);
            5. h: h=log(c^2/s^2).
        """
        q = np.asarray(q, dtype=np.float64)
        if q.shape != (self.dimension,):
            raise ValueError(f'q must be shape ({self.dimension},)')
        return q[0], q[1:1+self.p], q[1+self.p:1+2*self.p], q[-2], q[-1]

    def _transform(self, q):
        """Reconstruct the horseshoe cofficients."""
        b0, z, u, t, h = self._unpack(q)

        # 1. We define a_j = tau lambda_j
        # by our transformation: tau = tau0 exp(t), lambda_j = exp(u_j)
        # so a_j = tau0 exp(t+u_j), taking the log: log(a_j) = log(tau0) + (t+u_j)
        log_a = self._log_tau0 + t + u  # vector of shape (p,)

        # 2. We define w_j = log(a_j^2/c^2)
        # As c^2 = s^2 exp(h), then w_j = 2log(a_j) - log(s^2) - h
        w = 2*log_a - self._log_s2 - h

        # 3. Logit value: g=logit(w)
        g = expit(w)  # logistic sigmoid

        # As beta_j sim N(0, tau^2 tilde{lambda_j}^2), the scale is tau tilde{lambda_j}
        # and we try non-centered convention that beta_j = tau*tilde{lambda_j}z_j, with z_j sim N(0,1) 
        # Since we let a_j = tau lambda_j, 
        # follow the definition of tilde{lambda_j} gives us 
        # scale^2=(ca_j^2)/(c^2 + a_j^2), and recall w_j=log(a_j^2/c^2)
        log_scale = log_a - 0.5*np.logaddexp(0.0, w)  # log(a) - 0.5log(1+exp(w))
        scale = np.exp(log_scale)
        beta = z * scale  # beta_j sim N(0, tau^2 tilde{lambda_j}^2)
        return b0, z, u, t, h, g, scale, beta

    def value_and_gradient(self, q):
        """
        Compute the posterior potential U and its potential,
        return (negative log posterior U, gradient grad U).
        """
        b0, z, u, t, h, g, scale, beta = self._transform(q)
        eta = b0 + self.X @ beta  # logit parameter

        # log-likelihood, assuming independence of every y
        ll = self.y @ eta - np.sum(np.logaddexp(0.0, eta))

        # log-prior in 5 components
        logprior = (
            -0.5*(b0/self.intercept_sd)**2  # intercept log-prior: beta0 sim N(0,5^2)
            - 0.5*np.dot(z, z)  # non-centered Gaussian variables: z_j sim N(0,1), iid
            + np.sum(u - np.logaddexp(0.0, 2*u))  # the local half-Cauchy prior: lambda_j sim C+(0,1)
            + t - np.logaddexp(0.0, 2*t)  # the global half-Cauchy prior: tau sim C+(0, tau0)
            - self._a*h - self._a*np.exp(-h)  # the inverse Gamma slab prior: c^2 sim InvGamma(mu/2, nu s^2/2)
        )
        
        resid = self.y - expit(eta)
        dbeta = self.X.T @ resid
        common = dbeta*beta*(1.0 - g)
        grad_logpost = np.empty(self.dimension, dtype=np.float64)
        grad_logpost[0] = np.sum(resid) - b0/self.intercept_sd**2
        grad_logpost[1:1+self.p] = dbeta*scale - z
        grad_logpost[1+self.p:1+2*self.p] = common + 1.0 - 2.0*expit(2*u)
        grad_logpost[-2] = np.sum(common) + 1.0 - 2.0*expit(2*t)
        grad_logpost[-1] = 0.5*np.sum(dbeta*beta*g) - self._a + self._a*np.exp(-h)
        return -float(ll+logprior), -grad_logpost

    def potential(self, q):
        return self.value_and_gradient(q)[0]

    def gradient(self, q):
        return self.value_and_gradient(q)[1]

    def coefficients(self, q):
        """Return beta0, beta, log(tau), log(c^2) on substantive scales."""
        b0, z, u, t, h, g, scale, beta = self._transform(q)
        return {'intercept': b0, 'beta': beta,
                'log_tau': self._log_tau0+t,
                'log_c2': self._log_s2+h,
                'slab_fraction': g}

    def initial(self, kind='neutral', seed=1):
        """Convenient starts in *unconstrained* q coordinates.

        neutral: z~N(0,1), u=0, t=h=0
        cold_small: tau ~ tau0*exp(-5), lambdas ~exp(-2)
        cold_large: tau ~ tau0*exp(+5), lambdas ~exp(+2)
        dispersed: independent uniform(-2,2) entries (Stan-like in q)
        """
        rng = np.random.default_rng(seed)
        q = np.zeros(self.dimension)
        if kind == 'dispersed':
            return rng.uniform(-2., 2., size=self.dimension)
        q[1:1+self.p] = rng.normal(size=self.p)
        if kind == 'neutral':
            pass
        elif kind == 'cold_small':
            q[1+self.p:1+2*self.p] = -2.0
            q[-2] = -5.0
        elif kind == 'cold_large':
            q[1+self.p:1+2*self.p] = 2.0
            q[-2] = 5.0
        else:
            raise ValueError('kind: neutral, cold_small, cold_large, dispersed')
        return q


def simulated_sparse_logistic(n=100, p=100, p_signal=5, rho=0.5,
                              signal=1.5, seed=2026):
    """Return (standardized X, binary y, true beta, true intercept).

    AR(1)-correlated *feature* columns, not time-dependent observations.
    Standardizing the training X matters for the shrinkage prior.
    """
    if not (n > 2 and p > 1 and 1 <= p_signal <= p and -1 < rho < 1):
        raise ValueError('invalid n, p, p_signal or rho')
    rng = np.random.default_rng(seed)
    X = rng.normal(size=(n, p))
    for j in range(1, p):
        X[:, j] = rho*X[:, j-1] + np.sqrt(1-rho*rho)*X[:, j]
    X = (X-X.mean(axis=0))/X.std(axis=0, ddof=1)
    beta = np.zeros(p)
    active = np.linspace(0, p-1, p_signal, dtype=int)
    beta[active] = signal * np.where(np.arange(p_signal)%2 == 0, 1, -1)
    b0 = -0.25
    y = rng.binomial(1, expit(b0 + X@beta)).astype(np.int64)
    return X, y, beta, b0


def check_gradient(target, state=None, step=1e-5, num_checks=24, seed=2026):
    """Independent central finite-difference check of the analytic grad(U)."""
    q = target.initial('dispersed', seed=seed) if state is None else np.asarray(state, dtype=float)
    rng = np.random.default_rng(seed)
    indices = rng.choice(q.size, size=min(num_checks,q.size), replace=False)
    analytical = target.gradient(q)
    discrepancies = []
    for i in indices:
        plus, minus = q.copy(), q.copy()
        plus[i] += step
        minus[i] -= step
        numerical = (target.potential(plus)-target.potential(minus))/(2*step)
        discrepancies.append(abs(numerical-analytical[i]) / max(1, abs(numerical), abs(analytical[i])))
    return float(np.max(discrepancies))


def compare_four_samplers(target, initial_position, stepsize, n_samples,
                          make_sampler, run_chain, seed=2026,
                          nuts_selection='biased_progressive',
                          gist_selection='uniform_progressive',
                          sampler_kwargs=None):
    """Adapter: pass the existing make_sampler and run_chain functions.

    Does not change the user's NUTS/GIST transition kernels or their exactness.
    Use burn_in=0 to preserve the complete cold-start transient.
    All four kernels get the *same* initial q and fixed stepsize.
    """
    sampler_kwargs = dict(sampler_kwargs or {})
    q0 = np.asarray(initial_position, dtype=float)
    if q0.shape != (target.dimension,):
        raise ValueError('initial_position has incorrect shape')
    methods = [('NUTS','nuts',nuts_selection),
               ('c-NUTS','c-nuts',nuts_selection),
               ('GIST','gist',gist_selection),
               ('c-GIST','c-gist',gist_selection)]
    out = {}
    for idx, (label, algorithm, selection) in enumerate(methods):
        options = dict(potential=target.potential,
                       gradient=target.gradient,
                       dimension=target.dimension,
                       algorithm=algorithm,
                       stepsize=stepsize,
                       selection=selection,
                       seed=seed+idx)
        if algorithm.startswith('c-'):
            options['center'] = np.zeros(target.dimension)
        options.update(sampler_kwargs)
        sampler = make_sampler(**options)
        out[label] = run_chain(sampler, initial_position=q0.copy(),
                               n_samples=n_samples, burn_in=0, thin=1)
    return out


def cold_start_diagnostics(target, sampler_results, active_features=None):
    """Return trace arrays for cold-start plots (no inappropriate early ESS)."""
    traces = {}
    for name, result in sampler_results.items():
        Q = np.asarray(result['samples'], dtype=float)
        betas = np.stack([target.coefficients(q)['beta'] for q in Q])
        traces[name] = {
            'log_tau': Q[:, -2]+np.log(target.global_scale),
            'log_c2': Q[:, -1]+2*np.log(target.slab_scale),
            'beta_norm': np.linalg.norm(betas, axis=1),
            'beta_active': betas[:, active_features] if active_features is not None else None,
            'potential': np.array([target.potential(q) for q in Q]),
        }
    return traces
